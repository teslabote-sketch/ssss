"use strict";

const os     = require("os");
const config = require("../config.json");

module.exports = {
  name: "info",
  aliases: ["about", "botinfo"],
  description: "معلومات تفصيلية عن البوت والخادم.",
  usage: "info",
  category: "General",

  async execute({ api, event }) {
    const uptimeSeconds = Math.floor(process.uptime());
    const h = Math.floor(uptimeSeconds / 3600);
    const m = Math.floor((uptimeSeconds % 3600) / 60);
    const s = uptimeSeconds % 60;
    const uptime = `${h}s ${m}d ${s}th`;

    const mem   = process.memoryUsage();
    const memMB = (mem.rss / 1024 / 1024).toFixed(1);
    const botID = api.getCurrentUserID();

    const msg =
      `⚡ ${config.bot.name.toUpperCase()} v${config.bot.version}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `▸ الاسم    : ${config.bot.name}\n` +
      `▸ الإصدار  : ${config.bot.version}\n` +
      `▸ البادئة  : ${config.prefix}\n` +
      `▸ المعرف   : ${botID}\n` +
      `─────────────────────────\n` +
      `▸ النظام   : ${os.platform()} / ${os.arch()}\n` +
      `▸ Node.js  : ${process.version}\n` +
      `▸ التشغيل  : ${h}س ${m}د ${s}ث\n` +
      `▸ الذاكرة  : ${memMB} MB\n` +
      `▸ المعالج  : ${os.cpus()[0].model.trim()}\n` +
      `▸ الأنوية  : ${os.cpus().length}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━`;

    api.sendMessage(msg, event.threadID);
  },
};
