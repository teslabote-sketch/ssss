"use strict";

module.exports = {
  name: "ping",
  aliases: ["pong"],
  description: "التحقق من حالة البوت وقياس زمن الاستجابة.",
  usage: "ping",
  category: "General",

  async execute({ api, event }) {
    const latency = event.timestamp ? Date.now() - event.timestamp : null;

    let bar = "";
    let status = "";
    if (latency !== null) {
      if      (latency < 200)  { bar = "▓▓▓▓▓"; status = "ممتاز"; }
      else if (latency < 500)  { bar = "▓▓▓▓░"; status = "جيد"; }
      else if (latency < 1000) { bar = "▓▓▓░░"; status = "مقبول"; }
      else                     { bar = "▓▓░░░"; status = "بطيء"; }
    }

    const text = latency !== null
      ? `⚡ متصل — ${latency}ms\n${bar} ${status}`
      : `⚡ متصل — زمن الاستجابة غير متاح`;

    api.sendMessage(text, event.threadID);
  },
};
