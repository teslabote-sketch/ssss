"use strict";

const config = require("../config.json");

module.exports = {
  name: "help",
  aliases: ["h", "cmds", "commands"],
  description: "عرض قائمة جميع الأوامر أو تفاصيل أمر معين.",
  usage: "help [command]",
  category: "General",

  async execute({ api, event, args, commands }) {
    const prefix = config.prefix;
    const botName = config.bot.name;

    // ── تفاصيل أمر واحد ────────────────────────────────────────────────────
    if (args[0]) {
      const name = args[0].toLowerCase().replace(/^-+/, "");
      const cmd  = commands.get(name) ||
        [...new Set(commands.values())].find(c => c.aliases?.includes(name));
      if (!cmd) {
        return api.sendMessage(`✖ الأمر "${name}" غير موجود.`, event.threadID);
      }
      const lines = [
        `⚡ ${prefix}${cmd.name}`,
        `━━━━━━━━━━━━━━━━━━━━━━`,
        `▸ الوصف    : ${cmd.description}`,
        `▸ الفئة    : ${cmd.category || "General"}`,
        `▸ الاستخدام: ${prefix}${cmd.usage || cmd.name}`,
      ];
      if (cmd.aliases?.length) {
        lines.push(`▸ اختصارات : ${cmd.aliases.map(a => prefix + a).join("  ")}`);
      }
      if (cmd.adminOnly) lines.push(`▸ الصلاحية : مشرف فقط 🔒`);
      if (cmd.groupOnly) lines.push(`▸ النطاق   : مجموعات فقط 👥`);
      return api.sendMessage(lines.join("\n"), event.threadID);
    }

    // ── قائمة كل الأوامر ──────────────────────────────────────────────────
    const unique     = [...new Set(commands.values())];
    const categories = {};

    for (const cmd of unique) {
      const cat = cmd.category || "General";
      if (!categories[cat]) categories[cat] = [];
      categories[cat].push(cmd.name);
    }

    const ORDER = ["General", "Info", "Utility", "Group", "Admin", "Fun"];
    const sorted = [
      ...ORDER.filter(c => categories[c]),
      ...Object.keys(categories).filter(c => !ORDER.includes(c)),
    ];

    const ICONS = {
      General : "◈",
      Info    : "◈",
      Utility : "◆",
      Group   : "◉",
      Admin   : "◉",
      Fun     : "◇",
    };

    const total = unique.length;
    let msg = `⚡ ${botName} — الأوامر (${total})\n`;
    msg    += `━━━━━━━━━━━━━━━━━━━━━━\n`;

    for (const cat of sorted) {
      const icon = ICONS[cat] || "▸";
      const cmds = categories[cat].map(n => `${prefix}${n}`).join("  ");
      msg += `\n${icon} ${cat}\n${cmds}\n`;
    }

    msg += `\n━━━━━━━━━━━━━━━━━━━━━━`;
    msg += `\n${prefix}help <أمر> ← للتفاصيل`;

    api.sendMessage(msg, event.threadID);
  },
};
